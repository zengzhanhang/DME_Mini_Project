from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import numpy as np
from os import path
import glob
import scipy.sparse as sp
import os
import generateverctor
import tensorflow as tf

sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))
#config = tf.ConfigProto( device_count = {'GPU': 1 , 'CPU': 3} ) 
#sess = tf.Session(config=config) 
keras.backend.set_session(sess)


def readfile():
    contants = []
    labels = []
    uni = []
    allfiles = glob.glob('processed/**/*', recursive=True)
    # with open(path.abspath(filepath)) as fp:
    for line in allfiles:
        # line = "processed/" + line.strip() + ".txt"
        #read contants of each file
        try:
            with open(path.abspath(line)) as file:
                data = file.read().replace("\n", " ")
                contants.append(data)
        except:
            continue
        # add label for each file
        tags = path.normpath(line).split(os.sep)
        if tags[1] == 'course':
            labels.append('0')
        elif tags[1] == 'department':
            labels.append('1')
        elif tags[1] == 'faculty':
            labels.append('2')
        elif tags[1] == 'other':
            labels.append('3')
        elif tags[1] == 'project':
            labels.append('4')
        elif tags[1] == 'staff':
            labels.append('5')
        elif tags[1] == 'student':
            labels.append('6')
        # add university for each file
        if tags[2] == 'cornell':
            uni.append('cornell')
        elif tags[2] == 'misc':
            uni.append('misc')
        elif tags[2] == "texas":
            uni.append("texas")
        elif tags[2] == "washington":
            uni.append("washington")
        elif tags[2] == "wisconsin":
            uni.append("wisconsin")
    return contants, labels, uni

def tfidf():
    contants, labels, uni = readfile()
    tfidf = TfidfVectorizer(stop_words="english")
    vectors = tfidf.fit_transform(contants)
    return vectors, labels, uni, tfidf.get_feature_names()  # uni = university

def bow():
    contants, labels, uni = readfile()
    bow = CountVectorizer(stop_words="english")
    vectors = bow.fit_transform(contants)
    return vectors, labels, uni, bow.get_feature_names()

# test
if __name__ == '__main__':
    # contants, labels = readfile("testpath.txt")
    # print(contants[1], labels[1])
    vectors, labels, uni, features = tfidf()
    print(vectors.shape, len(labels), len(uni))

def splitvector(vectors, labels, uni, testuni):
    idx = [i for i,x in enumerate(uni) if x == testuni]
    test_vector = vectors[idx]
    test_label = np.array(labels)[idx]
    train_vector = sp.csr_matrix(np.delete(vectors.toarray(), idx, 0))
    train_label = np.delete(labels, idx)
    return train_vector, train_label, test_vector, test_label

train_vector, train_label, test_vector, test_label = splitvector(vectors, labels, uni, "cornell")

print('============ Start autoencoder ============')

vectors, labels, uni, filename, features = generateverctor.tfidf()
print(vectors.shape)

def svd(vectors):
    svd = TruncatedSVD(n_components=90)
    return svd.fit_transform(vectors)


def splitvector(vectors, labels, uni, testuni):
    # split vector and label to train and test
    idx = [i for i, x in enumerate(uni) if x == testuni]
    test_vector = vectors[idx]
    test_label = np.array(labels)[idx]
    if isinstance(vectors, sp.csr_matrix):
        train_vector = sp.csr_matrix(np.delete(vectors.toarray(), idx, 0))
    else:
        train_vector = sp.csr_matrix(np.delete(vectors, idx, 0))
    train_label = np.delete(labels, idx)
    return train_vector, train_label, test_vector, test_label


def plot_confusion_matrix(y_true, y_pred, classes,
                          normalize=False,
                          title=None,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if not title:
        if normalize:
            title = 'Normalized confusion matrix'
        else:
            title = 'Confusion matrix, without normalization'

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    # Only use the labels that appear in the data
    # classes = classes[unique_labels(y_true, y_pred)]
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           # ... and label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           title=title,
           ylabel='True label',
           xlabel='Predicted label')

    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")

    # Loop over data dimensions and create text annotations.
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], fmt),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    return ax


def svmclassfier(train_vector, train_label, test_vector):
#     lin_clf = svm.LinearSVC()
#     lin_clf.fit(train_vector, train_label)
#     predict = lin_clf.predict(test_vector)
    rbf_clf = SVC(kernel="linear", probability=True, random_state=2019)
    rbf_clf.fit(train_vector, train_label)
    predict = rbf_clf(test_vector)
    return predict



def lrclassifier(train_vector, train_label, test_vector):
    lr_clf = LogisticRegression()
    lr_clf.fit(train_vector, train_label)
    predict = lr_clf.predict(test_vector)
    return predict


train_vector, train_label, test_vector, test_label = splitvector(vectors, labels, uni, "cornell")
print(train_vector.shape)

# encodode dim
encoding_dim = 20

#input dim
input_doc = Input(shape=(88346,))

#encoder layer
encoded = Dense(44173, activation='relu')(input_doc)
encoded = Dense(20000, activation='relu')(encoded)
encoded = Dense(10000, activation='relu')(encoded)
encoded = Dense(3000, activation='relu')(encoded)
encoded = Dense(500, activation='relu')(encoded)
encoder_output = Dense(200)(encoded)

#decoder layer
decouded = Dense(500, activation='relu')(decouded)
decouded = Dense(3000, activation='relu')(decouded)
decouded = Dense(10000, activation='relu')(decouded)
decouded = Dense(20000, activation='relu')(decouded)
decouded = Dense(44173, activation='relu')(decouded)
decouder_output = Dense(88346, activation='relu')(decouded)

#autoecoder model
autoencoder = Model(input=input_doc, output=decouder_output)

#encoder model
encoder = Model(input=input_doc, output=encoder_output)

#complie autoencoder
autoencoder.compile(optimizer='adam', loss='mse')

#train model
autoencoder.fit(train_vector, train_vector,
               epochs = 2,
               batch_size = 100,
               shuffle = True)

print('test before save: ', encoder.predict(train_vector))
encoder.save('my_encoder_v1.h5')   # HDF5 file, you have to pip3 install h5py if don't have it
del encoder  # deletes the existing model

# load
encoder = load_model('my_encoder_v1.h5')
print('test after load: ', encoder.predict(train_vector))